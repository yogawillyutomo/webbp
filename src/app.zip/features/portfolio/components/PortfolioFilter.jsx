"use client";

import { useRef, useEffect, useState } from "react";

export default function PortfolioFilter({
    categories,
    activeCategory,
    setActiveCategory
}) {

    const containerRef = useRef(null);
    const buttonRefs = useRef([]);

    const [indicatorStyle, setIndicatorStyle] = useState({});
    const [isAnimating, setIsAnimating] = useState(false);


    /*
    ===================================
    UPDATE SLIDING INDICATOR
    ===================================
    */

    useEffect(() => {

        const index = categories.indexOf(activeCategory);

        const button = buttonRefs.current[index];
        const container = containerRef.current;

        if (!button || !container) return;

        const containerRect = container.getBoundingClientRect();
        const buttonRect = button.getBoundingClientRect();

        const newLeft = buttonRect.left - containerRect.left;
        const newWidth = buttonRect.width;

        setIsAnimating(true);

        setIndicatorStyle({
            width: newWidth,
            transform: `translateX(${newLeft}px)`
        });


        /*
        ===================================
        AUTO SCROLL ACTIVE BUTTON
        ===================================
        */

        const scrollPosition =
            newLeft - containerRect.width / 2 + newWidth / 2;

        container.scrollTo({
            left: scrollPosition,
            behavior: "smooth"
        });


        const timeout = setTimeout(() => {
            setIsAnimating(false);
        }, 450);

        return () => clearTimeout(timeout);

    }, [activeCategory, categories]);


    return (

        <div className="flex justify-center mt-16 mb-24">
            <div className="relative portfolio-scroll-mask max-w-full">
                <div
                    ref={containerRef}
                    className="
                    relative z-20 flex flex-nowrap
                    overflow-x-auto no-scrollbar
                    pt-2 px-2 pb-3 rounded-full
                    bg-white/5 backdrop-blur-2xl
                    border border-white/10

                    shadow-[0_15px_40px_rgba(0,0,0,0.25)]
                    scroll-smooth
                    "
                    >

                    {/* SLIDING INDICATOR */}

                    <div
                        className={`
                    absolute top-2 bottom-2 left-0
                    rounded-full 
                    bg-white/90 dark:bg-white
                    backdrop-blur-md
                    shadow-[0_6px_20px_rgba(0,0,0,0.15)]
                    transition-all duration-500
                    ease-[cubic-bezier(0.22,1,0.36,1)]
                    ${isAnimating ? "scale-[1.04]" : "scale-100"}
                    `}
                        style={indicatorStyle}
                    />



                    {/* CATEGORY BUTTON */}

                    {categories.map((cat, index) => (

                        <button
                            key={cat}
                            ref={(el) => (buttonRefs.current[index] = el)}
                            onClick={() => setActiveCategory(cat)}

                            className={`
                            relative z-10
                            px-8 py-3
                            text-[15px]
                            font-black
                            tracking-wide
                            whitespace-nowrap
                            transition-all duration-300
                            active:scale-95
                            ${activeCategory === cat
                                    ? "text-black dark:text-black"
                                    : "text-gray-700 hover:text-black dark:text-white/70 dark:hover:text-white"
                                }
                        `}
                        >
                            {cat}
                        </button>

                    ))}

                </div>
            </div>
        </div>

    );

}